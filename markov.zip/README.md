# Alexa-MarkovObama
Uses the Alexa platform to ask Obama policy questions.
